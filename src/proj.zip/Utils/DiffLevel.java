package Utils;

public enum DiffLevel {

	easy,
	medium,
	hard ;
}
