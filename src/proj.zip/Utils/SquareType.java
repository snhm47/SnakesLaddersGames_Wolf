package Utils;

public enum SquareType {
	   SURPRISE,
	    QUESTION,
	    REGULAR;
}
