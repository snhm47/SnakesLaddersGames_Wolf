package Utils;

public enum Color {
	YELLOW , RED , GREEN , BLUE;
}
